
import 'dart:ui';

import 'package:amateurfunktrainer/coustom_libs/icons.dart';
import 'package:flutter/material.dart';

import '../constants.dart';

chapterwidget(var chapterNames,final chapternames, final subchapter){

  return Container(
    margin: EdgeInsets.only(top: std_padding, bottom: std_padding + 20),
    decoration: BoxDecoration(
      gradient: LinearGradient(
        begin: Alignment.topRight,
        end: Alignment.bottomLeft,
        colors: [
          Color(0x86c7f7),
          Color(0xFFEEEEEE)
        ],
      ),
      borderRadius: BorderRadius.all(Radius.circular(10)),
    ),
    child: Padding(
        padding: EdgeInsets.all(std_padding),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
                children: [
                  Expanded(child: Text(
                    "$chapternames",
                    style: TextStyle(
                      fontSize: 25,
                      fontWeight: FontWeight.w500,
                    ),
                  ),)
                ]
            ),
            ListView.builder(
                shrinkWrap: true,
              itemCount: subchapter.length,
                itemBuilder: (context, i) {
                  return Card(
                    margin: EdgeInsets.only(top: 24,right: 30),
                    child: Column(
                      children: [
                        ListTile(
                          leading: Icon(icon(i, subchapter)),
                          title: Text(
                            subchapter[i]["name"],
                            style: TextStyle(
                                fontWeight: FontWeight.w500
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                }
            )
          ],
        )
    )
  );
}
icon(var i, var subchapter){
  var iconname = subchapter[i]['icon'];
  if(iconname == null){
    return Icons.keyboard_arrow_right;
  }
  print(iconname);
  var icon = getMaterialIcon( name: '$iconname');
  print(icon);
  return icon;
}