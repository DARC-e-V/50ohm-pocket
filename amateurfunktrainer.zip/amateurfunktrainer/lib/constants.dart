import 'package:flutter/material.dart';

const primaryswatch = Color(0xFF0F5E98);
final double std_padding = 15;
final admin_mail = "mail@mail.de";
