class Menu{
  var data;
  List chapter = [];
  List chapternames = [];
  List subchapter = [];

  main_chapter_names() => this.data["chapter"]["name"];

  learn_module_name() => this.data["exam"]["name"];

  chapter_names(){
    var chaptername = data["chapter"]["chapter"];
    for(var i in chaptername){
      var _chapname = i["name"];
      chapternames.add(_chapname);
    }
    return chapternames;
  }

  subchapter_info(var chapter_id){
    var chaptername = data["chapter"]["chapter"];
    this.subchapter = [];
    for(var i in chaptername){
      var _chapname = i["name"];
      if(_chapname == chapter_id){
        for(var subchapter in i["chapter"]){
          this.subchapter.add(subchapter);
        }
      }
    }
    return subchapter;
  }
}