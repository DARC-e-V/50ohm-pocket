

import 'package:amateurfunktrainer/widgets/chapter.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'constants.dart';
import 'json.dart';

Widget selectlesson(var data) {
  var menu = Menu();
  menu.data = data;
  var chapternames = menu.chapter_names();
  var subchapter = menu.subchapter_info(chapternames[0]);
  print(subchapter[1]["icon"]);

  return ListView.builder(
            itemCount: chapternames.length + 1,
            itemBuilder: (context, i) {
              if(i < 1){
                return Padding(padding: EdgeInsets.only(top:20, right: std_padding, left: std_padding), child: Text(
                  menu.learn_module_name(),
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 35,
                    ),
                  )
                );
              }if(i == 1){
                Divider(
                  thickness: 20,
                );
              }
                return chapterwidget(menu.main_chapter_names(), chapternames[i -1], menu.subchapter_info(chapternames[i - 1]));
            }

  );
}

