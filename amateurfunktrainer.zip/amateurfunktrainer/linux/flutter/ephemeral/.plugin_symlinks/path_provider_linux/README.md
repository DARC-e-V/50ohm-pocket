# path_provider_linux

The linux implementation of [`path_provider`].

## Usage

This package is already included as part of the `path_provider` package dependency, and will
be included when using `path_provider` as normal. You will need to use version 1.6.10 or newer.
