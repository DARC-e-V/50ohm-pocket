# Amateurfunktrainer

#### Note this project is intended for the german ham exam, so no english translation.

![Screenshot von der App Benutzeroberfläche.](assets/screenshots/chapterscreen.png?raw=true)