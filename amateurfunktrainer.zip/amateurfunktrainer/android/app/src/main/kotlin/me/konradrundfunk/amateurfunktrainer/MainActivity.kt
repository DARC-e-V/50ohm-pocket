package me.konradrundfunk.amateurfunktrainer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
